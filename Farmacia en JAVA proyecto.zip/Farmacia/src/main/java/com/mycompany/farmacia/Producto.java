package com.mycompany.farmacia;

import javax.swing.JOptionPane;

public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;
    private String categoria;

    // Constructor
    public Producto(String nombre, String categoria, double precio, int cantidad) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.cantidad = cantidad; // Inicialización de cantidad en 0
    }

    // Getters y Setters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    // Método para gestionar ingreso de productos por categoría
    public void gestionarIngresoProductos(Categoria[] categorias, Producto[] productos) {
        boolean salirIngresarProductos = true;
        while (salirIngresarProductos) {
            String categoriasDisponibles = "Categorías disponibles:\n";
            for (int i = 0; i < categorias.length; i++) {
                if (categorias[i] != null) {
                    categoriasDisponibles += (i + 1) + ". " + categorias[i].getNombreCategoria() + "\n";
                }
            }
            categoriasDisponibles += "0. Volver al menú principal";

                 int opcionCategoria = -1;
        boolean entradaValida = false;
        // Ciclo para asegurar que se ingrese un número válido para la categoría
        while (!entradaValida) {
            try {
                String input = JOptionPane.showInputDialog(categoriasDisponibles);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Operación cancelada.");
                    return; // Salir del método si se cancela la operación
                }
                opcionCategoria = Integer.parseInt(input);
                entradaValida = true; // Salir del ciclo si la conversión fue exitosa
            } catch (NumberFormatException e) {
                // Capturar la excepción si se ingresa una letra o valor no numérico
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
            }
        } //funcion SI EL USUARIO PONE UNA LETRA O NULL SIGA FUNCIONANDO EL SISITEMA
       
            if (opcionCategoria == 0) {
                salirIngresarProductos = false;
                break;
            } else if (opcionCategoria > 0 && opcionCategoria <= categorias.length && categorias[opcionCategoria - 1] != null) {
                Categoria categoriaSeleccionada = categorias[opcionCategoria - 1];

                String productosEnCategoria = "Productos en la categoría " + categoriaSeleccionada.getNombreCategoria() + ":\n";
                int productoIndex = 1;  // Se utiliza para mostrar la lista de productos correctamente
                Producto[] productosCategoria = new Producto[100];
                int index = 0;
                for (int i = 0; i < productos.length; i++) {
                    // Verificar si el producto no es nulo
                    boolean productoExiste = productos[i] != null;

                    // Verificar si la categoría del producto coincide con la categoría seleccionada
                    boolean categoriaCoincide = false;
                    if (productoExiste) {
                        categoriaCoincide = productos[i].getCategoria().equals(categoriaSeleccionada.getNombreCategoria());
                    }

                    // Si el producto existe y la categoría coincide, agregar a la lista
                    if (productoExiste && categoriaCoincide) {
                        productosEnCategoria += productoIndex + ". " + productos[i].getNombre() + " Cantidad disponible: " + productos[i].getCantidad() + "\n";
                        productosCategoria[productoIndex - 1] = productos[i];
                        productoIndex++;
                    }
                }
                productosEnCategoria += "0. Volver a selección de categoría";
                 int opcionProducto = -1;
            entradaValida = false;
            // Ciclo para asegurar que se ingrese un número válido para el producto
            while (!entradaValida) {
                try {
                    String input = JOptionPane.showInputDialog(productosEnCategoria);
                    if (input == null) {
                        JOptionPane.showMessageDialog(null, "Operación cancelada.");
                        return; // Salir del método si se cancela la operación
                    }
                    opcionProducto = Integer.parseInt(input);
                    entradaValida = true; // Salir del ciclo si la conversión fue exitosa
                } catch (NumberFormatException e) {
                    // Capturar la excepción si se ingresa una letra o valor no numérico
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
                }
            }
//funcion SI EL USUARIO PONE UNA LETRA O NULL SIGA FUNCIONANDO EL SISITEMA
             // int opcionProducto = Integer.parseInt(JOptionPane.showInputDialog(productosEnCategoria));
                if (opcionProducto == 0) {
                    continue;
                } else if (opcionProducto > 0 && opcionProducto < productoIndex) {
                    Producto productoSeleccionado = productosCategoria[opcionProducto - 1];


                // Solicitar la cantidad de productos a agregar
   
                int cantidadAgregar = -1;
                entradaValida = false;
                // Ciclo para asegurar que se ingrese un número válido para la cantidad a agregar
                while (!entradaValida) {
                    try {
                        String input = JOptionPane.showInputDialog("Ingrese la cantidad de productos a agregar para " + productoSeleccionado.getNombre());
                        if (input == null) {
                            JOptionPane.showMessageDialog(null, "Operación cancelada.");
                            return; // Salir del método si se cancela la operación
                        }
                        cantidadAgregar = Integer.parseInt(input);
                        entradaValida = true; // Salir del ciclo si la conversión fue exitosa
                    } catch (NumberFormatException e) {
                        // Capturar la excepción si se ingresa una letra o valor no numérico
                        JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
                    }
                }
                    // funcion SI EL USUARIO PONE UNA LETRA O NULL SIGA FUNCIONANDO EL SISITEMA
              
                // int cantidadAgregar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de productos a agregar para " + productoSeleccionado.getNombre()));

                    // Obtener la cantidad actual de productos
                    int cantidadActual = productoSeleccionado.getCantidad();

                    // Calcular la nueva cantidad
                    int nuevaCantidad = cantidadActual + cantidadAgregar;

                    // Actualizar la cantidad de productos
                    productoSeleccionado.setCantidad(nuevaCantidad);

                    // Mostrar mensajes al usuario
                    JOptionPane.showMessageDialog(null,
                            "Se han agregado " + cantidadAgregar + " productos de " + productoSeleccionado.getNombre());
                    JOptionPane.showMessageDialog(null,
                            "Cantidad actual de " + productoSeleccionado.getNombre() + ": " + nuevaCantidad);
                } else {
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        }
    }
    
    // Método para gestionar edición de precios de productos
    public void gestionarEdicionPrecios(Producto[] productos, Categoria[] categorias) {
        boolean salirEditarPrecio = true;
        while (salirEditarPrecio) {
            String categoriasDisponibles = "Categorías disponibles:\n";
            for (int i = 0; i < categorias.length; i++) {
                if (categorias[i] != null) {
                    categoriasDisponibles += (i + 1) + ". " + categorias[i].getNombreCategoria() + "\n";
                }
            }
            categoriasDisponibles += "0. Volver al menú principal";
int opcionCategoria = -1;
        boolean entradaValida = false;
        // Ciclo para asegurar que se ingrese un número válido para la categoría
        while (!entradaValida) {
            try {
                String input = JOptionPane.showInputDialog(categoriasDisponibles);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Operación cancelada.");
                    return; // Salir del método si se cancela la operación
                }
                opcionCategoria = Integer.parseInt(input);
                entradaValida = true; // Salir del ciclo si la conversión fue exitosa
            } catch (NumberFormatException e) {
                // Capturar la excepción si se ingresa una letra o valor no numérico
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
            }
        }

           // int opcionCategoria = Integer.parseInt(JOptionPane.showInputDialog(categoriasDisponibles));

            if (opcionCategoria == 0) {
                salirEditarPrecio = false;
                break;
            } else if (opcionCategoria > 0 && opcionCategoria <= categorias.length && categorias[opcionCategoria - 1] != null) {
                Categoria categoriaSeleccionada = categorias[opcionCategoria - 1];

                String productosEnCategoria = "Productos en la categoría " + categoriaSeleccionada.getNombreCategoria() + ":\n";
                int productoIndex = 1;  // Se utiliza para mostrar la lista de productos correctamente
                Producto[] productosCategoria = new Producto[100];
                for (int i = 0; i < productos.length; i++) {
                    // Verificar si el producto no es nulo y si pertenece a la categoría seleccionada
                    if (productos[i] != null && productos[i].getCategoria().equals(categoriaSeleccionada.getNombreCategoria())) {
                        productosEnCategoria += productoIndex + ". " + productos[i].getNombre() + " Precio: $" + productos[i].getPrecio() + "\n";
                        productosCategoria[productoIndex - 1] = productos[i];
                        productoIndex++;
                    }
                }
                productosEnCategoria += "0. Volver a selección de categoría";

            int opcionProducto = -1;
            entradaValida = false;
            // Ciclo para asegurar que se ingrese un número válido para el producto
            while (!entradaValida) {
                try {
                    String input = JOptionPane.showInputDialog(productosEnCategoria);
                    if (input == null) {
                        JOptionPane.showMessageDialog(null, "Operación cancelada.");
                        return; // Salir del método si se cancela la operación
                    }
                    opcionProducto = Integer.parseInt(input);
                    entradaValida = true; // Salir del ciclo si la conversión fue exitosa
                } catch (NumberFormatException e) {
                    // Capturar la excepción si se ingresa una letra o valor no numérico
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
                }
            }

               // int opcionProducto = Integer.parseInt(JOptionPane.showInputDialog(productosEnCategoria));

                if (opcionProducto == 0) {
                    continue;
                } else if (opcionProducto > 0 && opcionProducto < productoIndex) {
                    Producto productoSeleccionado = productosCategoria[opcionProducto - 1];
                    productoSeleccionado.editarPrecio(); // Llama al método editarPrecio() del producto seleccionado
                } else {
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        }
    }

    // Método para editar el precio de un producto
    public void editarPrecio() {
        
    boolean entradaValida = false;
    while (!entradaValida) {
        try {
            String input = JOptionPane.showInputDialog("Ingrese el nuevo precio del producto");
            if (input == null) {
                JOptionPane.showMessageDialog(null, "Edición de precio cancelada.");
                return; // Salir del método si se cancela la operación
            }
                     String salida = JOptionPane.showInputDialog("¿Estás seguro de cambiar el precio?\n"
                + "1. Para confirmar\n"
                + "2. Para cancelar");
            if ("1".equals(salida)){
            double nuevoPrecio = Double.parseDouble(input);
            this.precio = nuevoPrecio;
            JOptionPane.showMessageDialog(null, "El precio del producto se ha modificado con éxito");
            entradaValida = true;} // Salir del ciclo si la conversión fue exitosa
            else if ("2".equals(salida)){
            JOptionPane.showMessageDialog(null, " Opcion de editar precio fue cancelado");
            entradaValida = true;
            }
            else if (null==salida){
            JOptionPane.showMessageDialog(null, " Opcion de editar precio fue cancelado");
            entradaValida = true;
            }
            else{
            JOptionPane.showMessageDialog(null, " Opcion invalida");
            }
            
        } catch (NumberFormatException e) {
            // Capturar la excepción si se ingresa una letra o valor no numérico
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un precio válido (número).");
        }
    }

       // double nuevoPrecio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el nuevo precio del producto"));
       // this.precio = nuevoPrecio;
      //  JOptionPane.showMessageDialog(null, "El precio del producto se ha modificado con éxito");
    }



    public boolean verificarProducto(Producto[] productos, String nombreProducto) {
        for (int i = 0; i < productos.length; i++) {   // .length funciona para contar cuantos elementos hay en vector
                                                   //(cuentas todos los espacios en ese caso son 100)esta en el main (farmacia.java)
            
            if (productos[i] != null && nombreProducto.equals(productos[i].getNombre())) {//el .equals funciona como el == pero es mejor
                    /*             un ejemplo                                                       // compara contenido
                     String s1 = new String("hello");
                     String s2 = new String("hello");

                    System.out.println(s1 == s2);        // Output: false (compara referencias)
                    System.out.println(s1.equals(s2));   // Output: true (compara contenido)                                                                   
                    */                                                                    
                                                                                        
                JOptionPane.showMessageDialog(null, "El producto ya existe");
                return true; // Se devuelve true si el producto ya existe
            }
        }
        return false;
    }
}
