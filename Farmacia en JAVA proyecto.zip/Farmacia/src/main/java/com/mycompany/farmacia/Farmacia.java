/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.farmacia;

/**
 *
 * @author carlo
 */


import javax.swing.JOptionPane;

public class Farmacia {
    public static void main(String[] args) {
        Producto[] productos = new Producto[100];
        Categoria[] categorias = new Categoria[100];
        
        // Precargar productos
        productos[0] = new Producto("papel", "oficina", 2000, 23);
        productos[1] = new Producto("jabón", "limpieza", 1000, 12);
        
        // Precargar categorías
        categorias[0] = new Categoria("oficina");
        categorias[1] = new Categoria("limpieza");

        JOptionPane.showMessageDialog(null, "Bienvenido");

        Categoria categoriaInicializada = new Categoria("");
        Producto productoInicializado = new Producto("", "", 0.0, 0);

        boolean salir = true;
        while (salir) {
            String opcion = JOptionPane.showInputDialog("Menú principal:\n1. Registro\n2. Ingresar productos\n3. Editar precio\n4. Ver Inventario completo\n5. Salir");
            switch (opcion) {
                case "1":
                    boolean salir1 = true;
                    while (salir1) {
                        opcion = JOptionPane.showInputDialog("1.Registrar nuevo producto\n" +
                                                              "2.Registrar una categoría\n" +
                                                              "3.Para volver al menú principal");
                        switch (opcion) {
                            case "1":
                                String nombreProducto = JOptionPane.showInputDialog("Ingrese el nombre del producto");
                                if(nombreProducto==null){
                                    JOptionPane.showMessageDialog(null, "Edición de precio cancelada.");
                                continue;
                                }
                                if (productoInicializado.verificarProducto(productos, nombreProducto)) {
                                    continue;
                                }
                                int idex=1;
                                String InfCategorias = "";
                                for (int i=0; i< categorias.length;i++ ){
                                    if (categorias[i]!= null){
                                           InfCategorias += "\n" + idex + ". " + categorias[i].getNombreCategoria();
                                             idex++;}
                                }
                                String nombreCategoriaProducto = JOptionPane.showInputDialog("Ingrese el nombre de la categoría"+InfCategorias);
                                      if(nombreCategoriaProducto==null){
                                    JOptionPane.showMessageDialog(null, "Edición de precio cancelada.");
                                  continue;
                                          }
                                if (categoriaInicializada.verificarNombre(categorias, nombreCategoriaProducto)) {
                                    JOptionPane.showMessageDialog(null, "El nombre de la categoría NO existe");
                                    continue;
                                }
double precio = 0.0;
boolean temp = true;

while (temp) {
    try {
        String precioStr = JOptionPane.showInputDialog("Ingrese el precio del producto");
        
        // Verificar si se canceló la operación
        if (precioStr == null) {
            JOptionPane.showMessageDialog(null, "Edición de precio cancelada.");
            temp = false; // Salir del bucle
            break;
        }
        
        precio = Double.parseDouble(precioStr);

        String opcion1 = JOptionPane.showInputDialog("¿Estás seguro de registrar este producto?\n"
                + "1. Para confirmar\n"
                + "2. Para cancelar");

        if ("1".equals(opcion1)) {
            Producto nuevoProducto = new Producto(nombreProducto, nombreCategoriaProducto, precio, 0);

            for (int i = 0; i < productos.length; i++) {
                if (productos[i] == null) {
                    productos[i] = nuevoProducto;
                    JOptionPane.showMessageDialog(null, "Producto registrado exitosamente");
                    temp = false; // Salir del bucle
                    break;
                }
            }
        } else if ("2".equals(opcion1)) {
            JOptionPane.showMessageDialog(null, "Registro de producto cancelado");
            temp = false; // Salir del bucle
            break;}
            else if (null==opcion1){
            JOptionPane.showMessageDialog(null, "Registro de producto cancelado");
            temp = false; // Salir del bucle
                    }
        else {
            JOptionPane.showMessageDialog(null, "Opción inválida");
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Por favor, ingrese un precio válido (número).");
    }
} break;
                            case "2":
                                String nombreNuevaCategoria = JOptionPane.showInputDialog("Ingrese el nombre de la NUEVA categoría");
                                if(nombreNuevaCategoria==null){
                                    JOptionPane.showMessageDialog(null, "Edición de precio cancelada.");
                                continue;}
                                if (!categoriaInicializada.verificarNombre(categorias, nombreNuevaCategoria)) {
                                    JOptionPane.showMessageDialog(null, "Esa categoría YA EXISTE");
                                    continue;
                                }
                                temp=true;
                                while(temp){
                                String opcion1 = JOptionPane.showInputDialog("Estas SEGURO que seas registrar este producto\n"
                                        + "1. Para confimar\n"
                                          + "2. Para cancelar");
                                if ("1".equals(opcion1)){
                                Categoria nuevaCategoria = new Categoria(nombreNuevaCategoria);
                                for (int i = 0; i < categorias.length; i++) {
                                    if (categorias[i] == null) {
                                        categorias[i] = nuevaCategoria;
                                        JOptionPane.showMessageDialog(null, "Categoría registrada exitosamente");
                                        temp=false;
                                        break;
                                    }}
                                }
                                else if ("2".equals(opcion1)){
                                 JOptionPane.showMessageDialog(null, "Categoria fue cancelado");
                                 temp=false;
                                break;
                                    
                                }
                                else if (opcion1== null){
                               JOptionPane.showMessageDialog(null, "Categoria fue cancelado");
                                 temp=false;
                                break;
                                }
                                else {
                                JOptionPane.showMessageDialog(null, "Opcion Invalida");
                                }
                                }
                                break;
                            case "3":
                                salir1 = false;
                                break;
                            case null:
                                salir1 = false;
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Opción inválida");
                                break;
                        }
                    }
                    break;
                case "2":
                    // Llamar al método para gestionar ingreso de productos por categoría
                    productoInicializado.gestionarIngresoProductos(categorias, productos);
                    break;
                case "3":
                    // Llamar al método para gestionar edición de precios de productos
                    productoInicializado.gestionarEdicionPrecios(productos, categorias);
                    break;
                case "4":
                    // Lógica para ver inventario completo
                    String inventarioCompleto = "Inventario Completo:\n";
                    for (int i = 0; i < productos.length; i++) {
                        if (productos[i] != null) {
                            inventarioCompleto += productos[i].getNombre() + " Cantidad: " + productos[i].getCantidad() +" Categoria: "+productos[i].getCategoria()+ " - Precio: $" + productos[i].getPrecio() + "\n";
                        }
                    }
                    JOptionPane.showMessageDialog(null, inventarioCompleto);
                break;
                case "5":
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema. ¡Hasta luego!");
                    salir = false;
                    break;
                    
                case null:
                  JOptionPane.showMessageDialog(null, "Saliendo del sistema. ¡Hasta luego!");
                    salir = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                    break;
            }
        }
    }
}