/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.farmacia;

/**
 *
 * @author carlo
 */

public class Categoria {
    private String nombreCategoria;

    // Constructor
    public Categoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public boolean verificarNombre(Categoria[] categorias, String nombreCategoriaProducto) {
        for (int i = 0; i < categorias.length; i++) {
            if (categorias[i] != null && categorias[i].getNombreCategoria().equals(nombreCategoriaProducto)) {
                return false; 
            }
        }
        
        return true;
    }
}

